# Resolv LLC #
![add_gtest](https://github.com/Ctr011/Resolv-LLC/actions/workflows/deckware_tests.yml/badge.svg)

## Founding ##
  We were started by a group of individuals who were ready to alter the way different industries work in 2023. They researched many differenet methods to automate and optimize the workflow of these industries. In their research journey they found what they were looking for. With their new found skills and techniques, they have now set their mission into motion.
## Mission ##
  We are a company which is taking the commitment to the automation and optimization of mundane tasks. We will discover the best solution which will both make you profitable and efficient. 
## Logo ##
![default view of team logo](https://github.com/Ctr011/Resolv-LLC/blob/a3026d0b942bafe60a05fe0d1d60c6aaa198044c/logo/Resolv-logos.jpeg)
## Team ##
Team Leader: Godfrey Lozada

Team Member 1: Mrinisha Adhikari

Team Member 2: Matthew Teng

Team Member 3: Calvin Trujillo
